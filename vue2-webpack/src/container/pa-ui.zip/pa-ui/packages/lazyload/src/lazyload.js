import Lazyload from 'vue-lazyload';
import 'pa-ui/src/style/empty.css';

export default Lazyload;
