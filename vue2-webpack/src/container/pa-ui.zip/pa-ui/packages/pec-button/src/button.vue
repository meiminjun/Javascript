<template>
  <button :disabled="disabled" @click="handleClick" :class="[buttonClass,{'disabled': disabled}]">
    <slot></slot>
  </button>
</template>

<script>
  /**
   * pa-header
   * @module components/button
   * @desc 按钮
   * @param {string} [type=default] - 显示类型，接受 primary, secondary, weak
   * @param {boolean} [disabled=false] - 禁用
   * @param {string} [size=normal] - 尺寸，接受 small, mid, big, large
   * @param {slot} - 显示文本
   *
   * @example
   * <pec-button size="large" type="primary">按钮</pec-button>
   */
  export default {
    name: 'pec-button',
    props: {
      disabled: Boolean, // 是否被禁
      fixed: Boolean, // 是否在页面底部
      size: {
        type: String,
        default: 'big',
        validator(value) {
          return [
            'small',
            'mid',
            'big',
            'large'
          ].indexOf(value) > -1;
        }
      },
      type: {
        type: String,
        default: 'primary',
        validator(value) {
          return [
            'primary',
            'secondary',
            'weak'
          ].indexOf(value) > -1;
        }
      }

    },

    methods: {
      handleClick($event) {
        if (this.disabled) {
          $event.preventDefault();
          $event.stopPropagation();
        } else {
          this.$emit('click', $event);
        }
      }
    },
    computed: {
      buttonClass: function() {
        let typeClass = {
          'primary': 'pec-primary-btn',
          'secondary': 'pec-secondary-btn',
          'weak': 'pec-weak-btn'
        }[this.type];

        let sizeClass = {
          'small': 'small',
          'mid': 'mid',
          'big': 'big',
          'large': 'large'
        }[this.size];

        return typeClass + ' ' + sizeClass;
      }
    }
  };
</script>

<style lang="css">
  button.pec-primary-btn,
  button.pec-secondary-btn,
  button.pec-weak-btn {
    -webkit-tap-highlight-color: transparent;
    -webkit-appearance: none;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -webkit-font-smoothing: antialiased;
    appearance: none;
    outline: none;
    border: none;
    display: inline-block;
    color: #FFFFFF;
    font-family: 'PingFang SC', 'Droid Sans';
    background: #F17940;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }

  button.pec-secondary-btn {
    color: #F17940;
    background: #FFFFFF;
    border: 1px solid #F17940;
  }

  .pec-primary-btn.big,
  .pec-secondary-btn.big {
    font-size: 16px;
    height: 45px;
    border-radius: 45px;
    padding-left: 36px;
    padding-right: 36px;
  }

  .pec-primary-btn.mid,
  .pec-secondary-btn.mid {
    font-size: 13px;
    height: 30px;
    border-radius: 30px;
    padding-left: 18px;
    padding-right: 18px;
  }

  .pec-primary-btn.small,
  .pec-secondary-btn.small {
    font-size: 11px;
    height: 20px;
    border-radius: 20px;
    padding-left: 12px;
    padding-right: 12px;
    font-family: arial;
  }

  .pec-primary-btn.large,
  .pec-secondary-btn.large {
    font-size: 16px;
    height: 45px;
    border-radius: 45px;
    padding-left: 36px;
    padding-right: 36px;
    display: block;
    width: 100%;
  }

  button.pec-weak-btn {
    font-size: 16px;
    height: 45px;
    border-radius: 45px;
    padding-left: 36px;
    padding-right: 36px;
    color: #63666B;
    background: #FFFFFF;
    border: 1px solid #63666B;
  }

  button.pec-primary-btn:active {
    background: #D85F2A;
  }

  button.pec-secondary-btn:active {
    color: #D85F2A;
    border-color: #D85F2A;
  }

  button.pec-primary-btn.disabled {
    background: #D9D9D9;
  }

  button.pec-secondary-btn.disabled {
    color: #D9D9D9;
    border-color: #D9D9D9;
  }
</style>
