<template>
  <div v-if="visible" class="pec-mask">
    <div class="pec-pop" :style="{ top: top }">
      <h3>{{title}}</h3>
      <div class="pec-pop-content">
        <div class="pec-pop-pwd" @click="clickPassword">
          <span v-for="n in maxLength" :class="{on: n-1 < password.length}"></span>
        </div>
        <p class="pec-pop-pwd-errer" v-if="tips">{{tips}}</p>
        <div v-if="vcode.visible" class="pec-pop-toa">
          <input type="text" v-model="vcode.text" @focus="vcodeFocusIn" placeholder="请输入手机验证码">
          <button :class="{disabled: vcodeClass}" @click="getVCode">{{vcodeBtnText}}</button>
        </div>
        <p class="pec-pop-pwd-tips" v-if="vcode.tips">{{vcode.tips}}</p>
        <p class="pec-pop-pwd-errer" v-if="vcode.errorTips">{{vcode.errorTips}}</p>
      </div>

      <div class="pec-pop-btn">
        <button class="primary-btn" @click="cancelClick">取消</button>
        <button :class="submitBtnClass" @click="submitClick">确定</button>
      </div>
    </div>
    <pec-keyboard v-if="keyboard"
                  :modal="false"
                  :mode="keyboardMode"
                  v-model="showKeyboard"
                  @click="handleKeyboardClick"
                  @ok="handleKeyboardOk"
    ></pec-keyboard>
  </div>
</template>

<style>
  .pec-mask {
    position: fixed;
    z-index: 20;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, .6);
  }

  .pec-pop {
    position: fixed;
    z-index: 30;
    top: 50%;
    left: 50%;
    padding-top: 30px;
    width: 80%;
    border-radius: 5px;
    overflow: hidden;
    background: #FFFFFF;
    -webkit-font-smoothing: antialiased;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }

  .pec-pop h3 {
    font-size: 16px;
    line-height: 1;
    font-weight: normal;
    padding: 0 42px 30px;
    text-align: center;
    color: #1e1e1e;
  }

  .pec-pop .pec-pop-content {
    position: relative;
    padding-left: 15px;
    padding-right: 15px;
  }

  .pec-pop .pec-pop-btn {
    position: relative;
    font-size: 0;
  }

  .pec-pop .pec-pop-btn:before {
    position: absolute;
    content: "";
    z-index: 1;
    top: 0;
    left: 0;
    width: 100%;
    height: 1px;
    background: #E6E6E6;
    transform: scaleY(0.5);
    -webkit-transform: scaleY(0.5);
    -webkit-transform-origin: 0 0;
    transform-origin: 0 0;
  }

  .pec-pop input, .pec-pop button {
    position: relative;
    outline: none;
    border-radius: 0;
    border: none;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    font-family: 'PingFang SC', 'Droid Sans';

    -webkit-font-smoothing: antialiased;
  }

  .pec-pop .pec-pop-btn button {
    font-size: 16px;
    width: 50%;
    height: 45px;
    background: #FFFFFF;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }

  .pec-pop .pec-pop-btn button:after {
    position: absolute;
    content: "";
    z-index: 1;
    top: 0;
    right: 0;
    width: 1px;
    height: 100%;
    background: #E6E6E6;
    transform: scaleX(0.5);
    -webkit-transform: scaleX(0.5);
    -webkit-transform-origin: 100% 0;
    transform-origin: 100% 0;
  }

  .pec-pop .pec-pop-btn button:last-child:after {
    display: none;
  }

  .pec-pop .pec-pop-btn .primary-btn {
    color: #6c7684;
  }

  .pec-pop .pec-pop-btn .orange-btn {
    color: #F17940;
  }

  .pec-pop .pec-pop-btn .disabled-btn {
    color: #b2b2b2;
  }

  .pec-pop-pwd {
    position: relative;
    font-size: 0;
    height: 45px;
    padding: 0 10px;
    margin-bottom: 28px;
    border-radius: 4px;
    border: 1px solid #b2b2b2;
  }

  .pec-pop-pwd span {
    position: relative;
    color: #e7e7e7;
    font-size: 0;
    line-height: 0;
    height: 8px;
    display: inline-block;
    text-align: center;
  }

  .pec-pop-pwd span:before {
    position: absolute;
    content: "";
    top: 50%;
    left: 50%;
    width: 8px;
    height: 8px;
    display: inline-block;
    border-radius: 8px;
    background: #e7e7e7;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
  }

  .pec-pop-pwd .on:before {
    background: #3F4246;
  }

  .pec-pop-toa {
    border-radius: 4px;
    border: 1px solid #ABABAB;
    margin-bottom: 28px;
  }

  .pec-pop-toa input {
    font-size: 14px;
    padding-left: 15px;
    width: 138px;
  }

  .pec-pop-toa button {
    font-size: 14px;
    color: #F17940;
    height: 45px;
    width: 7.5em;
    padding: 0px 7px;
    text-align: center;
    border-left: 1px solid #ABABAB;
    background: transparent;
  }

  .pec-pop-toa button.disabled {
    color: #B2B2B2;
  }

  .pec-pop-pwd-errer,
  .pec-pop-pwd-tips {
    color: #FC1520;
    font-size: 11px;
    padding-top: 8px;
    padding-bottom: 13px;
    margin-top: -28px;
    text-align: left;
  }

  .pec-pop-pwd-tips {
    color: #B2B2B2;
  }

  .pec-pop-pwd {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
  }

  .pec-pop-toa {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center
  }

  .pec-pop-pwd span {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
  }

  .pec-pop-name {
    color: #6c7684;
    font-size: 14px;
    text-align: center;
    margin-top: -15px;
  }

  .pec-pop-money {
    color: #F17940;
    font-size: 24px;
    text-align: center;
    margin-top: 10px;
  }

  .pec-pop-account {
    color: #B2B2B2;
    font-size: 11px;
    text-align: center;
    margin-top: 15px;
    margin-bottom: 25px;
  }
</style>

<script>
  import {default as PecKeyboard} from '../../pec-keyboard/index';

  export default {
    name: 'pec-pwd-dialog',

    components: {
      PecKeyboard
    },

    data() {
      return {
        defaultCountdown: 120,   // 倒计时默认120秒
        countdown: 0,
        clock: null,
        hasCountDown: false, 		// 是否倒数过
        showKeyboard: false,
        password: this.pwd
      };
    },

    props: {

      visible: {
        type: Boolean,
        default: false  // 密码键盘默认不显示
      },

      title: {
        type: String,
        default: '输入取款密码'
      },

      top: {
        type: String,
        default: '50%'
      },

      pwd: {
        type: String,
        default: ''
      },

      maxLength: {
        type: Number,
        default: 6
      },

      tips: {
        type: String
      },

      vcode: {
        type: Object,
        default: function() {
          return {
            visible: false,
            disable: true,
            timing: false,
            tips: '',
            errorTips: ''
          };
        }
      },

      keyboard: {
        type: Boolean,
        default: false
      },

      keyboardMode: String,

      bindToKeyboardOk: {
        type: Boolean,
        default: false
      }

    },

    watch: {
      'vcode.timing': {
        handler(val, oldVal) {
          this.calcTime(val);
        },
        deep: true
      },

      visible(val, oldVal) {
        if (!val) {
          this.reset();
        }
        this.$nextTick(()=> {
          this.showKeyboard = val;
        });
      }
    },

    computed: {
      vcodeClass() {
        return this.checkVodeDisable();
      },

      submitBtnClass() {
        let completed = this.checkComplete();
        return {
          'disabled-btn': !completed,
          'orange-btn': completed
        };
      },

      vcodeBtnText() {
        let text = '获取验证码';
        let vcode = this.vcode;

        if (vcode.timing) {
          text = `重新获取${this.countdown}s`;
        } else if (this.hasCountDown) {
          text = '重新获取';
        }

        return text;
      }

    },

    methods: {

      checkComplete() {
        return this.password.length >= this.maxLength && (this.vcode.visible ? !!this.vcode.message : true);
      },

      checkVodeDisable() {
        return this.vcode.disable || this.vcode.timing;
      },

      cancelClick() {
        this.$emit('cancel');
      },

      getVCode() {
        if (!this.checkVodeDisable()) {
          this.vcode.disable = true;
          this.$emit('get-vcode');
        }
      },

      /**
       * 验证码计时 status {bool} true 开始计时，false取消
       */
      calcTime(status) {
        let time = this.defaultCountdown;
        let _this = this;

        clearTimeout(this.clock);

        if (status) {
          let loop = function() {
            _this.countdown = time;
            if (time !== 0) {
              _this.clock = setTimeout(function() {
                time -= 1;
                loop();
              }, 1000);
            } else {
              _this.calcTimeEnd();
            }
          };
          loop();
        }

      },

      calcTimeEnd() {
        this.vcode.timing = false;
        this.hasCountDown = true;
        this.vcode.disable = false;
      },

      reset() {
        this.vcode.timing = false;
        this.hasCountDown = false;
        this.vcode.disable = false;
        this.vcode.tips = '';
        this.vcode.errorTips = '';
        this.vcode.text = '';
      },

      hide() {
        this.visible = false;
      },

      submitClick() {
        if (this.checkComplete()) {
          console.log(this.vcode.text);
          this.$emit('submit', {
            vcode: this.vcode.text,
            pwd: this.password
          });
        }
      },

      vcodeFocusIn() {
        this.showKeyboard = false;
      },

      clickPassword() {
        if (!this.showKeyboard) {
          this.showKeyboard = true;
        }
      },

      handleKeyboardClick(val) {
        if (val.length <= this.maxLength) {
          this.password = val;
        }
      },

      handleKeyboardOk() {
        if (this.bindToKeyboardOk) {
          this.submitClick();
        }
      }
    }
  };
</script>
