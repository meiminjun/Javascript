export { default } from './src/password-dialog.vue';
