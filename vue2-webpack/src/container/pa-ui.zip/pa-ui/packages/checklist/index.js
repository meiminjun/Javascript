export { default } from './src/checklist.vue';
