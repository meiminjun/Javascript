<template>
  <div v-show="visible">
    <div class="pec-mask"></div>
    <div class="pec-pop">
      <h3 v-show="!!title">{{title}}</h3>
      <div class="pec-header-padding" v-show="!(!!title && !!message)"></div>
      <div class="pec-pop-content" v-show="!!message">
        <div class="pec-pop-main" v-bind:style="{maxHeight : maxHeight + 'px'}" >
          <div class="pec-pop-message" v-html="message"></div>
          <div class="msg-mask-layer" v-show="showLayer"></div>
        </div>
      </div>

      <div class="pec-pop-btn pec-by-vertical" v-if="type==='alert'">
        <button class="orange-btn" @click="bundle.action()" v-html="bundle.buttonText"></button>
      </div>

      <div class="pec-pop-btn" v-if="type==='confirm'">
        <button class="primary-btn" @click="bundle.leftAction()" v-html="bundle.leftText"></button>
        <button class="orange-btn" @click="bundle.rightAction()" v-html="bundle.rightText"></button>
      </div>

      <div class="pec-pop-btn pec-by-vertical" v-if="type==='sheet'">
        <button class="orange-btn" @click="bundle.firstAction()" v-html="bundle.firstText"></button>
        <button class="orange-btn" @click="bundle.secondAction()" v-html="bundle.secondText"></button>
        <button class="primary-btn" @click="bundle.thirdAction()" v-html="bundle.thirdText"></button>
      </div>
    </div>
  </div>

</template>

<script>
  export default {
    name: 'pec-message-box',
    data: function() {
      return {
        visible: true,
        showLayer: false,
        maxHeight: 0,
        type: '', // 弹窗类型：alert、confirm、sheet
        title: '提示',
        message: '',
        bundle: {}
      };
    }
  };
</script>

<style lang="css" scoped>
  input,
  button {
    font: inherit;
    -webkit-appearance: none;
    appearance: none;
    outline: none;
    -webkit-tap-highlight-color: transparent;
    border-radius: 0;
    border: none;
  }

  button {
    font: inherit;
    -webkit-appearance: none;
    appearance: none;
    outline: none;
    -webkit-tap-highlight-color: transparent;
    border-radius: 0;
    border: none;
  }
  /*弹窗背景*/

  .pec-mask {
    position: fixed;
    z-index: 20;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: #000000;
    opacity: .6;
  }

  .pec-pop {
    position: fixed;
    z-index: 30;
    top: 50%;
    left: 50%;
    width: 80%;
    padding-top: 30px;
    border-radius: 5px;
    overflow: hidden;
    background: #FFFFFF;
    -webkit-font-smoothing: antialiased;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }

  .pec-pop h3 {
    font-size: 16px;
    line-height: 1;
    font-weight: normal;
    padding: 0 42px 15px;
    text-align: center;
  }

  .pec-header-padding {
    height: 15px;
    width:30px;

  }

  .pec-pop .pec-pop-content {
    position: relative;
    padding-left: 15px;
    padding-right: 15px;
  }

  .pec-pop .pec-pop-main {
    max-height: 125px;
    padding-left: 26px;
    padding-right: 26px;
    margin-bottom: 20px;
    line-height: 1.5;
    text-align: justify;
    overflow-y: auto;
  }

  .pec-pop .pec-pop-main .pec-pop-message {
    font-size: 14px;
    color: #3f4246;
    /*zdk*/
  }

  .pec-pop .pec-pop-main .pec-pop-message-tips {
    font-size: 11px;
    color: #ABABAB;
    margin-top: 10px;
  }

  .pec-pop .pec-pop-message-mask {
    position: absolute;
    left: 0;
    bottom: 0;
    right: 20px;
    height: 13px;
    background-image: -webkit-linear-gradient(top, rgba(255, 255, 255, 0), #fff 80%);
  }

  .pec-pop .pec-pop-btn {
    position: relative;
    font-size: 0;
  }

  .pec-pop .pec-pop-btn:before {
    position: absolute;
    content: "";
    z-index: 1;
    top: 0;
    left: 0;
    width: 100%;
    height: 1px;
    background: #E6E6E6;
    transform: scaleY(0.5);
    -webkit-transform: scaleY(0.5);
    -webkit-transform-origin: 0 0;
    transform-origin: 0 0;
  }

  .pec-pop .pec-pop-btn button {
    position: relative;
    outline: none;
    border-radius: 0;
    border: none;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    font-family: 'PingFang SC', 'Droid Sans';
    font-size: 16px;
    width: 50%;
    height: 45px;
    background: #FFFFFF;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }

  .pec-pop .pec-pop-btn button:after {
    position: absolute;
    content: "";
    z-index: 1;
    top: 0;
    right: 0;
    width: 1px;
    height: 100%;
    background: #E6E6E6;
    transform: scaleX(0.5);
    -webkit-transform: scaleX(0.5);
    -webkit-transform-origin: 100% 0;
    transform-origin: 100% 0;
  }

  .pec-pop .pec-pop-btn button:last-child:after {
    display: none;
  }

  .pec-pop .pec-pop-btn .primary-btn {
    color: #63666B;
  }

  .pec-pop .pec-pop-btn .orange-btn {
    color: #F17940;
  }

  .pec-pop .pec-pop-btn .disabled-btn {
    color: #DADADA;
  }

  .pec-pop .pec-pop-btn.pec-by-vertical button {
    position: relative;
    width: 100%;
    border-right: 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }

  .pec-pop .pec-pop-btn.pec-by-vertical button:after {
    position: absolute;
    content: "";
    z-index: 1;
    top: initial;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 1px;
    background: #E6E6E6;
    transform: scaleY(0.5);
    -webkit-transform: scaleY(0.5);
    -webkit-transform-origin: 0 100%;
    transform-origin: 0 100%;
  }

  .pec-pop .pec-pop-btn.pec-by-vertical button:last-child:after {
    display: none;
  }

  .msg-mask-layer {
    background-image: -webkit-linear-gradient(rgba(104,145,167, 0) 0, rgb(255, 255, 255) 100%);
    margin-bottom: -2px;
    height: 40px;
    z-index: 99;
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
  }
</style>