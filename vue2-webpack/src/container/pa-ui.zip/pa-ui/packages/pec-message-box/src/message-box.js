import Vue from 'vue';
import MsgBox from './message-box.vue';

let MessageBoxConstructor = Vue.extend(MsgBox);

let merge = function(target) {
  for (let i = 1, j = arguments.length; i < j; i++) {
    var source = arguments[i];
    for (let prop in source) {
      if (source.hasOwnProperty(prop)) {
        var value = source[prop];
        if (value !== undefined) {
          target[prop] = value;
        }
      }
    }
  }

  return target;
};

let MessageBox = function(options) {
  if (!options.type) {
    return console.warn('请输入弹窗类型。');
  }

  let instance = MessageBox._getInstance();
  let distOptions = merge({
    visible: true,
    showLayer: false,
    maxHeight: window.innerHeight * 0.28
  }, options);

  for (let prop in distOptions) {
    if (distOptions.hasOwnProperty(prop)) {
      instance[prop] = distOptions[prop];
    }
  }
  document.body.appendChild(instance.$el);

  if (!instance.message) {
    return;
  }

  let count_down = 50;
  let interval = setInterval(function() {
    let dom = instance.$el.getElementsByClassName('pec-pop-main');
    let leng = dom[0].offsetHeight;

    if (leng !== 0) {
      instance.showLayer = leng > window.innerHeight * 0.26;
      clearInterval(interval);
    }

    count_down--;
    count_down <= 0 && clearInterval(interval);
  }, 50);
};

// 单例方法
MessageBox._getInstance = function() {
  if (!MessageBox._instance) {
    MessageBox._instance = new MessageBoxConstructor({el: document.createElement('div')});
  }
  return MessageBox._instance;
};

/**
 * 单按钮alert弹窗
 * @param options
 *   title：提示框的标题
 *   message：提示框的内容
 *   buttonText：按钮文字。默认'确认'
 *   action：点击回调函数
 *   keep：回调执行结束，是否保留弹窗。默认：false
 */
MessageBox.alert = function(options) {
  let opt = {
    type: 'alert',
    title: options.title || '提示',
    message: options.message || '',
    bundle: {
      buttonText: options.buttonText || '确认',
      action: function() {
        options.action && options.action();
        !options.keep && MessageBox.close();
      }
    }
  };

  MessageBox(opt);
};

/**
 * 双按钮confirm弹窗
 * @param options
 *   title：提示框的标题
 *   message：提示框的内容
 *   leftText：左边按钮文字。默认：取消
 *   leftAction：左边点击回调函数
 *   rightText：右边点击回调函数。默认：确定
 *   rightAction：右边点击回调函数
 *   keep：回调执行结束，是否保留弹窗。默认：false
 */
MessageBox.confirm = function(options) {
  let opt = {
    type: 'confirm',
    title: options.title || '提示',
    message: options.message || '',
    bundle: {
      leftText: options.leftText || '取消',
      leftAction: function() {
        options.leftAction && options.leftAction();
        !options.keep && MessageBox.close();
      },
      rightText: options.rightText || '确认',
      rightAction: function() {
        options.rightAction && options.rightAction();
        !options.keep && MessageBox.close();
      }
    }
  };

  MessageBox(opt);
};

/**
 * 三按钮sheet弹窗
 * @param options
 *   title：提示框的标题
 *   message：提示框的内容
 *   firstText：第一个按钮文字
 *   firstAction：第一个点击回调函数
 *   secondText：第二个按钮文字
 *   secondAction：第二个点击回调函数
 *   thirdText：第三个按钮文字
 *   thirdAction：第三个点击回调函数
 *   keep：回调执行结束，是否保留弹窗。默认：false
 */
MessageBox.sheet = function(options) {
  let opt = {
    type: 'sheet',
    title: options.title || '提示',
    message: options.message || '',
    bundle: {
      firstText: options.firstText || '',
      firstAction: function() {
        options.firstAction && options.firstAction();
        !options.keep && MessageBox.close();
      },
      secondText: options.secondText || '',
      secondAction: function() {
        options.secondAction && options.secondAction();
        !options.keep && MessageBox.close();
      },
      thirdText: options.thirdText || '取消',
      thirdAction: function() {
        options.thirdAction && options.thirdAction();
        !options.keep && MessageBox.close();
      }
    }
  };

  MessageBox(opt);
};

/**
 * 关闭弹窗
 */
MessageBox.close = function() {
  MessageBox._getInstance().visible = false;
};

export default MessageBox;
