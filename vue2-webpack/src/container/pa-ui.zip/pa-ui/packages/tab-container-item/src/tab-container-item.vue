<template>
  <div
    v-show="$parent.swiping || id === $parent.currentActive"
    class="pa-tab-container-item">
    <slot></slot>
  </div>
</template>

<script>
/**
 * pa-tab-container-item
 * @desc 搭配 tab-container 使用
 * @module components/tab-container-item
 *
 * @param {number|string} [id] - 该项的 id
 *
 * @example
 * <pa-tab-container v-model="selected">
 *   <pa-tab-container-item id="1"> 内容A </pa-tab-container-item>
 *   <pa-tab-container-item id="2"> 内容B </pa-tab-container-item>
 *   <pa-tab-container-item id="3"> 内容C </pa-tab-container-item>
 * </pa-tab-container>
 */
export default {
  name: 'pa-tab-container-item',

  props: ['id']
};
</script>

<style>
  @component-namespace pa {
    @component tab-container-item {
      flex-shrink: 0;
      width: 100%;
    }
  }
</style>
