export { default } from './src/keyboard.vue';
