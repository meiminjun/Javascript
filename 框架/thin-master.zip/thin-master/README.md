thin
====

a simple thin js framework

为了写一个构建前端框架的系列文章而写的一个JavaScript框架，编写的原则是：

使用方便
实现优雅
容易理解

为了达到这些目标，可能牺牲一些灵活性和性能。
