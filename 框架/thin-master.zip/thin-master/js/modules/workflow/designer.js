thin.define("WorkflowPanel", ["Events"], function (Events) {

});

thin.define("");
