thin.define("WorkflowEngine", ["Events"], function (Events) {

});