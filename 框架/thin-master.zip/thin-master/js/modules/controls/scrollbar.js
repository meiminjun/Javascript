thin.define("ScrollBar", ["_", "Events"], function (_, Events) {
	var ScrollBar = function(element, config) {
		element.innerHTML = "";
	};

	ScrollBar.prototype = {

	};

	return ScrollBar;
}；