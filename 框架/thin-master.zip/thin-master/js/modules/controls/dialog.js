thin.define("Dialog", [], function () {

	var Dialog = function () {

	};

	Dialog.prototype = {
		show: function () {

		},

		hide: function () {

		}
	};

	return Dialog;
});